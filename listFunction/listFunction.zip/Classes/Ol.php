<?php


class Ol extends TList
{

}