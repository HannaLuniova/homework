<?php

include '../vendor/autoload.php';

(new Luniova\Router())->run();
//(new Luniova\Router())->usdByn();

